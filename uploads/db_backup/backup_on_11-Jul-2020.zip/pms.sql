#
# TABLE STRUCTURE FOR: items
#

DROP TABLE IF EXISTS `items`;

CREATE TABLE `items` (
  `items_id` int(11) NOT NULL AUTO_INCREMENT,
  `items_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`items_id`)
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=latin1;

INSERT INTO `items` (`items_id`, `items_name`) VALUES (1, 'Analog Camera');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (2, 'Computer');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (3, 'Laptop');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (4, 'Pendrive');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (5, 'SD card');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (7, 'Laser Printer');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (8, 'Inject Printer');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (9, 'Photography Bag');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (10, 'Wifi Router');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (11, 'Projector');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (12, 'HDD');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (13, 'Camera Lens');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (14, 'HONOUR BOARD');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (15, 'Dongle');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (17, 'Photo Printing Paper');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (18, 'Printing Paper');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (19, 'Router');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (20, 'Towel');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (21, 'cartain');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (22, 'Cabels');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (23, 'Extaintion Cord');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (24, 'Blackmagic Camera');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (25, 'Domes');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (26, 'Constable');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (27, 'Jackets');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (28, 'Rasper Acrylic Sandwich');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (29, 'Cartridges for printers');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (30, 'Computer Peripherals');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (31, 'Finger Print development articles');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (32, 'TONER');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (33, 'HEAD SET');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (34, 'HDMI to AV Converter');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (35, 'SDI TO HDMI CONVERTER');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (36, 'OPTICAL TO SDI CONVERTER');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (37, 'UPS');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (38, 'VIDEO CAMERA ');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (39, 'HANDICAM');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (40, 'COMPUTER PERIPHERALS');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (41, 'COLOUR FLIM PROCESS DEVELOPER');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (42, 'OPTICAL FIBER CABLE');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (43, 'OPTICAL FIBER CONVERTER(BLACKMAGIC)');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (44, 'STUDIO FIBER CONVERTOR(BLACKMAGIC)');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (45, 'ECM-CG50 SHOT GUN MICROPHONE(SONY)');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (46, 'SENNHIEISER 281 PRO SINGLE SIDED HEADPHONE');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (47, 'HP i5 ADAPTER ');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (48, 'DIGITAL CAMERA');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (49, 'PLOTER');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (50, 'HAND GLAPS');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (51, 'HALF JACKET');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (52, 'SHOE CAP');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (53, 'EXHIBIT COLLECTING BAG');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (54, 'PRINTER RIBBON FOR DUPLET ORPHICARD IDENTITY CARD ');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (55, 'PREPRINTED CARD FOR DUPLET ORPFICARD');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (56, 'DUPLET CLEANING CARD');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (57, '124-A BLACK');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (58, '124-A YELLOW');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (59, '124-A CYAN');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (60, '124-A MAGENTA');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (61, 'HP LASERJET MANAGED MFP E72630dn');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (62, 'HP LASERJET m452dn');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (63, 'ORPHICARD HALF PANEL RIBBON');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (65, 'HDMI SPLITER-(MODEL-SP-0104-H2/4 PORT/WIRESTROME)');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (66, 'SDI DISTRIBUTION MINI CONVERTOR(BLACKMAGIC)(1 IN 8 OUT)');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (67, 'HDMI CABLE (WIRESTROME-3 Mtr)');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (68, 'USB 302 TYPE-C TO HDMI 2.0 I4K 60 HZ CABLE');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (69, 'SMALL RIG(BLACKMAGIC) VIDEO ASSIST SDI CABLE');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (70, 'BLACKMAGIC DESINE MINI XLR CABLE FOR VIDEO ASSIST/4K');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (71, 'GRAPHIC CARD DUAL PORT SUPPORTED WITH DDR5');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (72, '4K HDMI CABLE 3 MTR GOOD QUALITY ');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (73, 'RCA CABLE ');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (74, 'BLACKMAGIS DESIGN DECKLINK SDI 4K CAPTURE & PLAYBACK CARD');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (75, 'BELDEN/CANARE SDI CABLE 10 MTR.');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (76, 'BELDEN/CANARE SDI CABLE 05 MTR.');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (77, 'BELDEN/CANARE SDI CABLE 01 MTR.');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (78, 'PPE-FULL SET (BOTH COVERALL AND GROWN-DIPOSABLE & NON DISPOSABLE)-ISO 16604');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (79, 'SURGICAL HAND GLOVES(IN PAIRS)');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (80, 'SUGICAL MASK');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (81, 'SHOE-CAPS(IN PAIRS)');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (82, 'FACE SHIELDS/FACE GUARDS');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (83, 'SANIISER-SPRAY BOTTLES-1 Lt.');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (84, 'DETTOL BOTTLES');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (85, 'LIQUID HAND WASH-BOTTLES');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (86, 'HEAD COVER');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (87, 'FACE MASK COTTON MADE');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (88, 'EXTERNAL HARD DISK-2TB');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (89, 'MICRO SD CARD -32GB');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (90, 'FRS SOFTWARE INSTALATION FOR 100 CAMERAS');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (91, 'SPRAY GUN');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (92, 'PHENYL');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (93, 'SURGICAL FACE MASK');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (94, 'OPC DRUM');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (95, 'METAL BLADE');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (96, 'MAGNETIC STICK/CARBON STICK');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (97, 'DISPLAY-27 \" ULTRA HD LED(DELL,HP)');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (98, 'PROCESSOR-I7 9TH GN INTEL');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (99, 'RAM -16 GB WITH HARD D');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (100, 'JACKETS');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (101, 'INK TANK PFI-8310 BLACK CANON IMAGE PROGRAF TX-5400 ');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (102, 'INK TANK PFI-8310 CYAN CANON IMAGE PROGRAF TX-5400 ');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (103, 'INK TANK PFI-8310 MAGENTA CANON IMAGE PROGRAF TX-5400 ');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (104, 'INK TANK PFI-8310 YELLOW CANON IMAGE PROGRAF TX-5400 ');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (105, 'INK TANK PFI-8710 MATTE BLACK CANON IMAGE PROGRAF TX-5400 ');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (106, '08 GB MICRO SD CARD');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (107, 'INK CYAN EPSON SURE LAB-S1-D3000');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (108, 'INK MAGENTA EPSON SURE LAB-S1-D3000');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (109, 'INK YELLOW EPSON SURE LAB-S1-D3000');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (110, 'INK BLACK EPSON SURE LAB-S1-D3000');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (111, 'INK LIGHT CYAN EPSON SURE LAB-S1-D3000');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (112, 'INK LIGHT MAGENTA EPSON SURE LAB-S1-D3000');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (113, 'FORTIGATE 50E FIREWALL DEVICE');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (114, 'FRS CAMERA');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (115, 'UTP TRIAL PRISONERS');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (116, 'DATABASE SERVER (MY SQL 5.7 WITH LEGENCY SUPPORT)');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (117, 'STORAGE(10-15 MB PER UTP RECORD)');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (118, 'SMS GETWAY MESSAGES');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (119, 'MOTHER BOARD');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (120, 'STORAGE-1TB HDD');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (121, 'GRAPHICS CARD-8GB DDR5 1080 Ti');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (122, 'GRAPHICS CARD-16 GB DDR5 1080 Ti');
INSERT INTO `items` (`items_id`, `items_name`) VALUES (123, 'WIRELESS KEY BOARD AND MOUSE');


#
# TABLE STRUCTURE FOR: process
#

DROP TABLE IF EXISTS `process`;

CREATE TABLE `process` (
  `p_id` int(11) NOT NULL AUTO_INCREMENT,
  `p_orn` varchar(255) NOT NULL,
  `p_type` varchar(255) NOT NULL,
  `p_recievedate` date NOT NULL DEFAULT '0000-00-00',
  `p_recievefrom` varchar(255) NOT NULL,
  `p_memono` varchar(255) NOT NULL,
  `p_subject` varchar(255) NOT NULL,
  `p_senddate` date NOT NULL DEFAULT '0000-00-00',
  `p_sendto` varchar(255) NOT NULL,
  `p_remarks` varchar(255) NOT NULL,
  `p_ocputup_date` date NOT NULL DEFAULT '0000-00-00',
  `p_status` varchar(255) NOT NULL,
  `p_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `p_flag` int(11) NOT NULL,
  `p_userid` int(11) NOT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

INSERT INTO `process` (`p_id`, `p_orn`, `p_type`, `p_recievedate`, `p_recievefrom`, `p_memono`, `p_subject`, `p_senddate`, `p_sendto`, `p_remarks`, `p_ocputup_date`, `p_status`, `p_datetime`, `p_flag`, `p_userid`) VALUES (3, '405812', 'File', '2020-01-08', 'CPW,KP', '07/37/KPCPW/C', 'BLOOD DONATION CAMP UTSARGA', '2020-01-08', 'ADDLOC SW', 'NONE', '2020-01-08', 'Active', '2020-03-11 00:00:00', 1, 2);
INSERT INTO `process` (`p_id`, `p_orn`, `p_type`, `p_recievedate`, `p_recievefrom`, `p_memono`, `p_subject`, `p_senddate`, `p_sendto`, `p_remarks`, `p_ocputup_date`, `p_status`, `p_datetime`, `p_flag`, `p_userid`) VALUES (4, '295912', 'File', '2020-01-14', 'OC/SW DD', 'NONE', 'YEARLY REPORT OF SW. DD FOR 2019', '2020-01-14', 'JT. CP (C)', 'NONE', '2020-01-14', 'Active', '2020-03-11 00:00:00', 1, 2);
INSERT INTO `process` (`p_id`, `p_orn`, `p_type`, `p_recievedate`, `p_recievefrom`, `p_memono`, `p_subject`, `p_senddate`, `p_sendto`, `p_remarks`, `p_ocputup_date`, `p_status`, `p_datetime`, `p_flag`, `p_userid`) VALUES (5, '365912', 'File', '2020-01-15', 'EQP, CELL KPD   ', 'NONE', 'SUPPLY COLOUR FILM PROCESS DEVELOPER AT PHOTOGRAPHY SEC. SW/DD', '2020-03-11', 'NONE', 'NONE', '2020-01-15', 'Active', '2020-03-11 00:00:00', 1, 2);
INSERT INTO `process` (`p_id`, `p_orn`, `p_type`, `p_recievedate`, `p_recievefrom`, `p_memono`, `p_subject`, `p_senddate`, `p_sendto`, `p_remarks`, `p_ocputup_date`, `p_status`, `p_datetime`, `p_flag`, `p_userid`) VALUES (6, '365912', 'File', '2020-01-16', 'SW/DD', 'NONE', 'SUPPLY COLOUR FILM PROCESS DEVELOPER AT PHOTOGRAPHY SEC. SW DD', '2020-01-16', 'DC CYBER', 'NONE', '2020-01-16', 'Active', '2020-03-11 00:00:00', 1, 2);
INSERT INTO `process` (`p_id`, `p_orn`, `p_type`, `p_recievedate`, `p_recievefrom`, `p_memono`, `p_subject`, `p_senddate`, `p_sendto`, `p_remarks`, `p_ocputup_date`, `p_status`, `p_datetime`, `p_flag`, `p_userid`) VALUES (7, '515912', 'File', '2020-01-17', 'NONE', 'NONE', 'LAYERED VOICE ANALYSIS (LAV) & SUSPECT DETECTION SYSTEM (SDS) FOR CRIME PREVENTION DETECTION & INVEST-1 GATTON JT CP CRIME/ CR(1) 95', '2020-01-17', 'SW DD (SHAKIT) CPC', 'NONE', '2020-01-17', 'Active', '2020-03-11 00:00:00', 1, 2);
INSERT INTO `process` (`p_id`, `p_orn`, `p_type`, `p_recievedate`, `p_recievefrom`, `p_memono`, `p_subject`, `p_senddate`, `p_sendto`, `p_remarks`, `p_ocputup_date`, `p_status`, `p_datetime`, `p_flag`, `p_userid`) VALUES (8, '585912', 'File', '2020-01-21', 'NONE', 'NONE', 'ONE PRAYER ADDEMICY TO JT CP CRIME RECYANDINS MEGUINEN OF SOME WEB AITIELES FOR NOSTINS OF UTP AT CRS BY OC SW  DITY FOR WAIED BY AC DD (I)', '2020-03-11', 'NONE', 'NONE', '2020-01-21', 'Active', '2020-03-11 00:00:00', 1, 2);
INSERT INTO `process` (`p_id`, `p_orn`, `p_type`, `p_recievedate`, `p_recievefrom`, `p_memono`, `p_subject`, `p_senddate`, `p_sendto`, `p_remarks`, `p_ocputup_date`, `p_status`, `p_datetime`, `p_flag`, `p_userid`) VALUES (9, '040013', 'File', '2020-01-24', 'NONE', '381/ADDI CP (III)', 'INTERACTIVE VISUALIZATION & VIRTUAL REATILY', '2020-03-11', 'NONE', 'NONE', '2020-01-21', 'Active', '2020-03-11 00:00:00', 1, 2);
INSERT INTO `process` (`p_id`, `p_orn`, `p_type`, `p_recievedate`, `p_recievefrom`, `p_memono`, `p_subject`, `p_senddate`, `p_sendto`, `p_remarks`, `p_ocputup_date`, `p_status`, `p_datetime`, `p_flag`, `p_userid`) VALUES (10, '110013', 'File', '2020-01-24', 'RO DD JT CP CRIME ', 'SL NO- 820', 'INVITATION FOR VERTIV (LIEVERT) PRODUCT LINE DEMO', '2020-03-11', 'NONE', 'NONE', '2020-01-24', 'Active', '2020-03-11 00:00:00', 1, 2);
INSERT INTO `process` (`p_id`, `p_orn`, `p_type`, `p_recievedate`, `p_recievefrom`, `p_memono`, `p_subject`, `p_senddate`, `p_sendto`, `p_remarks`, `p_ocputup_date`, `p_status`, `p_datetime`, `p_flag`, `p_userid`) VALUES (11, '180013', 'File', '2020-01-25', 'JT CP CRIME', 'NONE', 'THE MILIMETER WAVE TECHNOLOGY FULL BOOTH SCANNER QILOOTEEH MIRO DOSE X-RAY IMAGIS TECHNOLOGY', '2020-01-25', 'NONE', 'NONE', '2020-01-25', 'Active', '2020-03-11 00:00:00', 1, 2);
INSERT INTO `process` (`p_id`, `p_orn`, `p_type`, `p_recievedate`, `p_recievefrom`, `p_memono`, `p_subject`, `p_senddate`, `p_sendto`, `p_remarks`, `p_ocputup_date`, `p_status`, `p_datetime`, `p_flag`, `p_userid`) VALUES (12, '240013', 'File', '2020-01-25', 'JT CP CRIME ', 'NONE', 'GAURAV DAS WEBDCSK STATUS REPORT OF FRS JTCP CRIME 164 ', '2020-01-25', 'SW DD(PRADIP)', 'NONE', '2020-01-25', 'Active', '2020-03-11 00:00:00', 1, 2);
INSERT INTO `process` (`p_id`, `p_orn`, `p_type`, `p_recievedate`, `p_recievefrom`, `p_memono`, `p_subject`, `p_senddate`, `p_sendto`, `p_remarks`, `p_ocputup_date`, `p_status`, `p_datetime`, `p_flag`, `p_userid`) VALUES (13, '300013', 'File', '2020-02-05', 'JT. CP(Crime)', 'Sl. No. 1.189 dt. 03-02-2020', 'Proposed for establishing a Digital Forensic Unit under physical Division this laboratory', '2020-02-05', 'HA RO DD', 'N/A', '2020-02-05', 'Active', '2020-03-20 00:00:00', 1, 3);
INSERT INTO `process` (`p_id`, `p_orn`, `p_type`, `p_recievedate`, `p_recievefrom`, `p_memono`, `p_subject`, `p_senddate`, `p_sendto`, `p_remarks`, `p_ocputup_date`, `p_status`, `p_datetime`, `p_flag`, `p_userid`) VALUES (14, '360013', 'File', '2020-02-28', 'JT. CP(C)', 'Memo No-399  dt. 27-02-2020', 'Request for a time slot to demonstrate the services in front you and your team during 2nd march to 6th march as per your convenient date and time', '2020-02-28', 'OC SW DD', 'N/A', '2020-02-28', 'Active', '2020-03-20 00:00:00', 1, 3);
INSERT INTO `process` (`p_id`, `p_orn`, `p_type`, `p_recievedate`, `p_recievefrom`, `p_memono`, `p_subject`, `p_senddate`, `p_sendto`, `p_remarks`, `p_ocputup_date`, `p_status`, `p_datetime`, `p_flag`, `p_userid`) VALUES (15, '410013', 'File', '2020-02-28', 'JT. CP(Crime)', 'Memo No-400  dt. 27-02-2020', 'Prayer for necessary permission for attending AIPDM, 2019', '2020-02-28', 'OC SW DD', 'N/A', '2020-02-28', 'Active', '2020-03-20 00:00:00', 1, 3);
INSERT INTO `process` (`p_id`, `p_orn`, `p_type`, `p_recievedate`, `p_recievefrom`, `p_memono`, `p_subject`, `p_senddate`, `p_sendto`, `p_remarks`, `p_ocputup_date`, `p_status`, `p_datetime`, `p_flag`, `p_userid`) VALUES (16, '470013', 'File', '2020-02-28', 'JT. CP(Crime)', 'Memo No-JT. CP(Crime)/C.I/58/20', 'Requesting for arranging 230v AC power input for CCTV equipment Installation near Girls schools and women colleges at different place in Kolkata under \'Nirbhaya Project\'', '2020-02-28', 'OC SW DD', 'N/A', '2020-02-28', 'Active', '2020-03-20 00:00:00', 1, 3);
INSERT INTO `process` (`p_id`, `p_orn`, `p_type`, `p_recievedate`, `p_recievefrom`, `p_memono`, `p_subject`, `p_senddate`, `p_sendto`, `p_remarks`, `p_ocputup_date`, `p_status`, `p_datetime`, `p_flag`, `p_userid`) VALUES (17, '560013', 'File', '2020-03-03', 'EQP CELL, KPD', 'File No-Teic -120/2019, Serial No-ID 1062619 DT. 20/12/2019', 'Supply of colour film process Developer at photography section of Scientific Wing, DD, Kolkata', '2020-03-03', 'OC SW DD', 'N/A', '2020-03-03', 'Active', '2020-03-20 00:00:00', 1, 3);
INSERT INTO `process` (`p_id`, `p_orn`, `p_type`, `p_recievedate`, `p_recievefrom`, `p_memono`, `p_subject`, `p_senddate`, `p_sendto`, `p_remarks`, `p_ocputup_date`, `p_status`, `p_datetime`, `p_flag`, `p_userid`) VALUES (18, '451198', 'File', '2020-03-03', 'OC SW DD', 'EMP ID CO/CPC/18/0189', 'Identity card issue', '2020-03-03', 'AO KPD, Kolkata Police HQ', 'N/A', '2020-03-03', 'Active', '2020-03-20 00:00:00', 1, 3);
INSERT INTO `process` (`p_id`, `p_orn`, `p_type`, `p_recievedate`, `p_recievefrom`, `p_memono`, `p_subject`, `p_senddate`, `p_sendto`, `p_remarks`, `p_ocputup_date`, `p_status`, `p_datetime`, `p_flag`, `p_userid`) VALUES (19, '581151', 'File', '2020-03-03', 'JT. CP(Crime)', 'Memo No-4077 RPT+RTI+ENCLOR. 75/2020 ID 107/231 SL. No- 2.503 FT. 38/02/2020', 'Furnishing information under RTI ACT 2005', '2020-03-03', 'OC SW DD', 'N/A', '2020-03-03', 'Active', '2020-03-20 00:00:00', 1, 3);
INSERT INTO `process` (`p_id`, `p_orn`, `p_type`, `p_recievedate`, `p_recievefrom`, `p_memono`, `p_subject`, `p_senddate`, `p_sendto`, `p_remarks`, `p_ocputup_date`, `p_status`, `p_datetime`, `p_flag`, `p_userid`) VALUES (20, '031239', 'File', '2020-03-06', 'JT. CP(Crime)', 'S. I L/O -8796 DT. 27-08-2020 File No-46/2018 ID 913334', 'Regarding procurement of IFVP Software', '2020-03-06', 'OC SW DD', 'N/A', '2020-03-06', 'Active', '2020-03-20 00:00:00', 1, 3);
INSERT INTO `process` (`p_id`, `p_orn`, `p_type`, `p_recievedate`, `p_recievefrom`, `p_memono`, `p_subject`, `p_senddate`, `p_sendto`, `p_remarks`, `p_ocputup_date`, `p_status`, `p_datetime`, `p_flag`, `p_userid`) VALUES (21, '031239', 'File', '2020-03-16', 'JT. CP(A)', 'Memo No. 290/F  Dt. 04-02-2020 Memo No. 306/JT. CP(A)', 'INTERACTIVE VISUALIZATION AND VIRTUAL REALITY', '2020-03-16', 'OC SW DD', 'N/A', '2020-03-16', 'Active', '2020-03-21 00:00:00', 1, 3);
INSERT INTO `process` (`p_id`, `p_orn`, `p_type`, `p_recievedate`, `p_recievefrom`, `p_memono`, `p_subject`, `p_senddate`, `p_sendto`, `p_remarks`, `p_ocputup_date`, `p_status`, `p_datetime`, `p_flag`, `p_userid`) VALUES (22, '131233', 'File', '2020-03-17', 'EQP CELL', 'File No-120/2019 SL. No. 20/12/2019 ID-1062619', 'Supply of color file process Developer photography Section of SW, DD, Kolkata', '2020-03-17', 'OC SW DD', 'N/A', '2020-03-17', 'Active', '2020-03-21 00:00:00', 1, 3);
INSERT INTO `process` (`p_id`, `p_orn`, `p_type`, `p_recievedate`, `p_recievefrom`, `p_memono`, `p_subject`, `p_senddate`, `p_sendto`, `p_remarks`, `p_ocputup_date`, `p_status`, `p_datetime`, `p_flag`, `p_userid`) VALUES (23, '201223', 'File', '2020-03-19', 'JT. CP(A)', 'ID 1075539', 'Supplier of articles for audiovisual of audio .', '2020-03-19', 'OC SW DD', 'N/A', '2020-03-19', 'Active', '2020-03-21 00:00:00', 1, 3);
INSERT INTO `process` (`p_id`, `p_orn`, `p_type`, `p_recievedate`, `p_recievefrom`, `p_memono`, `p_subject`, `p_senddate`, `p_sendto`, `p_remarks`, `p_ocputup_date`, `p_status`, `p_datetime`, `p_flag`, `p_userid`) VALUES (24, '261232', 'File', '2020-03-20', 'JT. CP(Crime)', 'N/A', 'Recommendable work done is matching of the Unknown Dead Body photo with the missing persons photo diaries long back in the year 2012', '2020-03-20', 'AC DD(I)', 'N/A ', '2020-03-20', 'Active', '2020-07-01 23:45:00', 1, 2);
INSERT INTO `process` (`p_id`, `p_orn`, `p_type`, `p_recievedate`, `p_recievefrom`, `p_memono`, `p_subject`, `p_senddate`, `p_sendto`, `p_remarks`, `p_ocputup_date`, `p_status`, `p_datetime`, `p_flag`, `p_userid`) VALUES (25, '311299', 'File', '2020-03-20', 'OC SW DD', 'N/A', 'Prayer for \'Fortigate 50E\' Firewall device for the use of \'Back Pack\' section', '2020-03-20', 'JT. CP(Crime)', 'N/A ', '2020-03-20', 'Active', '2020-06-24 11:35:00', 1, 2);


#
# TABLE STRUCTURE FOR: process_image
#

DROP TABLE IF EXISTS `process_image`;

CREATE TABLE `process_image` (
  `pi_id` int(11) NOT NULL AUTO_INCREMENT,
  `pi_pid` int(11) NOT NULL,
  `pi_name` varchar(255) NOT NULL,
  `pi_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pi_flag` int(11) NOT NULL,
  `pi_userid` int(11) NOT NULL,
  PRIMARY KEY (`pi_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `process_image` (`pi_id`, `pi_pid`, `pi_name`, `pi_datetime`, `pi_flag`, `pi_userid`) VALUES (2, 25, 'auth-bg.jpg', '2020-07-10 22:24:00', 1, 1);


#
# TABLE STRUCTURE FOR: process_status
#

DROP TABLE IF EXISTS `process_status`;

CREATE TABLE `process_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Process_Id` int(11) NOT NULL,
  `Status` varchar(255) NOT NULL,
  `Status_Date` date NOT NULL DEFAULT '0000-00-00',
  `Status_Time` time NOT NULL DEFAULT '00:00:00',
  `User_Id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: requisition
#

DROP TABLE IF EXISTS `requisition`;

CREATE TABLE `requisition` (
  `r_id` int(11) NOT NULL AUTO_INCREMENT,
  `r_orn` varchar(255) NOT NULL,
  `r_date` date NOT NULL,
  `r_sectionfor` varchar(200) NOT NULL,
  `r_sub` text NOT NULL,
  `r_towhom` varchar(200) NOT NULL,
  `r_forwardedto` varchar(200) NOT NULL,
  `r_dealingsec` varchar(200) NOT NULL,
  `r_recievedate` date NOT NULL,
  `r_status` varchar(200) NOT NULL,
  `r_supplydate` date NOT NULL,
  `r_remarks` text NOT NULL,
  `r_datetime` datetime NOT NULL,
  `r_flag` int(11) NOT NULL,
  `r_userid` int(11) NOT NULL,
  PRIMARY KEY (`r_id`)
) ENGINE=InnoDB AUTO_INCREMENT=158 DEFAULT CHARSET=latin1;

INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (1, '421852', '2018-11-27', 'SW DD', 'REQUIREMENT OF 04 NO.S i7 COMPUTER FOR SW DD', 'Jt. CP CRIME', 'Jt. CP O', 'COMPUTER SECTION', '0000-00-00', 'REJECTED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (2, '421888', '2018-10-05', 'SW DD', 'PRAYER FOR REPLACEMENT OF EXISTING OUT OF ORDER AC MACHINE OF THE ROOM OF O.C SW DD', 'JT CP(O)', 'DC.DD-II', 'O.C.BUILDING', '0000-00-00', 'REJECTED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (3, '421899', '2018-05-14', 'SW DD', 'PROPOSAL FOR ALLOTMENT OF TOTAL 35 NOS OF PHOTOGRAPHY BAGS FOR PHOTOGRAPHY SECTION AND VIDEOGRAPHY SECTION UNDER THE CONTROL OF SW DD', 'JT CP(O)', 'DC DD II', 'ICD LALBAZAR', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (4, '421897', '2018-05-14', 'SW DD', 'PROPOSAL FOR ALLOTMENT OF TOTAL 67 NOS OF JACKETS FOR ALL THE POLICE PERSONAL OF SCIENTIFIC WING, DD FOR EASY IDENTIFICATION.', 'JT CP(CRIME)', 'DC DD-II', 'ICD', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (5, '421861', '2018-04-06', 'SW DD', 'PRAYER FOR ISSUE OF 5 NOS OF MOTOR CYCLES (TWO WHEELERS) FOR THE USE OF SCIENTIFIC WINGS, DD AT AN EARLY DATE.', 'DC DD-II', 'AC DD I', 'MTO', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (6, '421854', '2018-02-14', 'SW DD', 'PRAYER FOR PROVIDING PHOTOGRAPHY JACKET AND WEARABLE QUALITY SAFARI FOR OUR PHOTOGRAPHY AND BACK-PACK TEAM', 'JTCP(CRIME)', 'DC DD-II', 'ICD ', '0000-00-00', 'RECEIVED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (7, '421884', '2018-10-31', 'SW DD', 'PRAYER FOR PROVIDING ONE EXTENSION CORD WITH MULTIPLE SPIKE GUARD FOR THE USE OF SW DD.', 'JTCP(O)', 'DC DD- II', 'OC BUILDING', '0000-00-00', 'RECEIVED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (8, '421850', '2018-09-06', 'SW DD', 'REQUIREMENT OF 64 GB PEN DRIVE(SANDISK/KINGSTONE) AND 200NO.OF MICRO SD CARDS (CLASS-10) OF DIFFERENT STORAGE CAPACITY FOR THE USE OF PHOTOGRAPHY SECTION , SW DD', 'DC DD-II', 'AC DD I', 'HA DD', '0000-00-00', 'RECEIVED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (9, '421839', '2018-03-27', 'SW DD', 'URGENTLY REQUIRED FOR THE USE OF PLAN MAKING A.SPEAKER - 2 PAITS. B.COLOUR PRRINTE  R A4 SIZE -1NO. C.PEN DRIVE  54 GB-12 NOS.D. PEN DRIVE 32 GB - 12 NOS. E. PEN DRIVE-12NOS', 'DC DD-II', 'AC DD-I', 'HA DD', '0000-00-00', 'RECEIVED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (10, '421849', '2018-04-10', 'SW DD', 'REQUIREMENT OF EACH OF 2 NOS CURTAINS AND TOWELS TO BE USED IN SW DD.', 'DC DD- II', 'AC DD I', 'HA DD', '0000-00-00', 'RECEIVED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (11, '421843', '2018-07-18', 'SW DD', 'PRAYER FOR CONSIDERATION OF THE FOLLOWING H.P.1-7 POSSESSON 27 INCH COMPUTRTS SET (DESKTOP) FOR THE USE OF PORTRAIT PARLE &  SW DD.', 'DC DD-II', 'HA DD', 'HA DD', '0000-00-00', 'RECEIVED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (12, '421843', '2019-02-12', 'SW DD', 'PRAYER FOR REQUIREMENT OF 3 NOs. DOMES ON CONTRACTUAL BASIS TO BE POSTED AT FP SEC. SW DD', 'JT. CP. (HQ)', 'DC DD (II)', 'HA ESTABLISHEDMENT SEC, LALBAZAR', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (13, '421874', '2019-02-12', 'SW DD', 'REQUIREMENT OF 10NOS OF16 GB PEN DRIVE (SANDISK/KINGSTONE),5 NOS OF 32 GB PENDRIVE (SANDISK/ KINGSTONE) AND 5 NOS OF 64 GB PENDRIVE OF SSTORAGE CAPASITY FOR THE USE OF DIFFERENT SECTION OF SW DD', 'DC II DD', 'AC DD I', 'HA DD', '0000-00-00', 'RECEIVED', '0000-00-00', '4 NOS OF 32 GB PENDRIVE ,2 NOS OF 64 GB PENDRIVE RECEIVED', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (14, '421835', '2019-02-06', 'SW DD', 'PRAYER TO PROVIDE 3 NOs WI-FI ROUTER (D- LINK DIR 816 WIRELESS AC 750 DUEL BAND ROUTER ) FOR THE USE OF SWDD', 'JT CP (O )', 'DC II DD', 'OC. TELEPHONE . LALBAZAR', '0000-00-00', 'RECEIVED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (15, '431839', '2019-01-29', 'SW DD', 'PRAYER FOR ISSUANCE OF FOLLOWING ARTICLES URGENTLY REQUIRED FOR USE OF SW DD', 'JT CP (O)', 'DC DD II', 'EQUIPMENT SECTION, LALBAZAR', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (16, '431814', '2019-01-23', 'SW DD', 'PRAYER FOR PASSING NECESSARY ORDER TO SUPPLY 10 PIECES OF TOSHISIBA EXTERNAL HARD DISK O2 TB ENCH FOR THE USE OF VIDEOGRAPHY AND BACK PACK SECTION', 'DC DD II', 'AC DD I', 'HA DD', '2019-03-20', 'RECEIVED', '0000-00-00', 'BRAND WD ', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (17, '431826', '2019-01-24', 'SW DD', 'ENHANCEMENT OF INTERNET DATA OF AIRTEL DONGLE CONNECTION WITH EXISTING DATA RATE OR LOWER THAN THE EXISTING DATA RATE REQUIRED FOR THE BACK PACK SECTION OF SW DD', 'JT CP (O)', 'DC DD II', 'O.C.TELEPHONE', '0000-00-00', 'RECEIVED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (18, '431822', '2019-01-23', 'SW DD', 'PRAYER FOR PASSING NECESSARY ORDER TO SUPPLY 2 PIECES PF HP LASER JET PRO MEP M226dn PRINTER CARTAGE OF VIDEOGRAPHY SECTION.', 'DC DD II', 'AC DD I', 'HA DD', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (19, '431893', '2019-01-23', 'SW DD', 'PRAYER FOR PASSING NECESSARY ORDER TO SUPPLY PHOTO PAPERS FOR EPSON SURE LAB SL D 3000 OF SW DD', 'DC DD II', 'AC DD I', 'HA DD ', '0000-00-00', 'RECEIVED', '0000-00-00', '19 peice received', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (20, '431841', '2019-01-23', 'SW DD', 'PRAYER FOR PASSING NECESSARY ORDER TO SUPPLYING 2 EPSON L-805 COLOUR PRINTER INK FOR THE DAILY USES OF VIDEOGRAPHY SECTION, SW DD', 'DC DD II', 'AC DD I', 'HA DD', '0000-00-00', 'RECEIVED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (21, '431874', '2019-01-23', 'SW DD', 'PRAYER FOR PASSING NECESSARY ORDER TO SUPPLYING 2 SET OF EPSON EXCEED YOUR VISION MAINTENCE TANK- MAINTRNANCE KIT FOR EPSON SURE LAB SL D 3000 OF SW DD', 'DC DD II', 'AC DD I', 'HADD', '0000-00-00', 'RECEIVED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (22, '431863', '2019-01-23', 'SW DD', 'PRAYER FOR PASSING NECESSARY ORDER TO SUPPLY PHOTO PAPERS FOR EPSON SURE LAB SL D 3000', 'DC DD II', 'AC DD I', 'HA DD', '0000-00-00', 'RECEIVED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (23, '431889', '2019-01-23', 'SW DD', 'PRAYER FOR PASSING NECESSARY ORDER TO SUPPLYING EPSON ULTRA CHROME D6 INK FOR EPSON SURE LAB SL D 3000 OF SW DD', 'DC DD II', 'AC DD I', 'HA DD ', '0000-00-00', 'RECEIVED', '0000-00-00', '1 set received', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (24, '431865', '2018-03-15', 'SW DD', 'DESKTOR COMPUTERS (I5/I7)', 'DC DD(11)', 'NA', 'NA', '0000-00-00', 'RECEIVED', '0000-00-00', 'NA', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (25, '431879', '2018-03-15', 'SW DD', 'POSTING OF NEW OFFICE CONSTABLE', 'DC DD(11)', 'NA', 'NA', '0000-00-00', 'RECEIVED', '0000-00-00', 'NA', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (26, '431877', '2018-03-14', 'SW DD', '2TB HDDC 10 PM', ' AO KPD', 'NA', 'NA', '0000-00-00', 'RECEIVED', '0000-00-00', 'NA', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (27, '431847', '2018-03-16', 'SW DD', 'HONOUR BOARD', 'OC BUILDING', 'NA', 'NA', '0000-00-00', 'RECEIVED', '0000-00-00', 'NA', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (28, '431870', '2018-08-01', 'SW DD', 'NIKKON LENS-25 MM (F/2) OR (F/1.8) WIDE ANGEL', 'AO KPD', 'HA DD', 'NA', '0000-00-00', 'RECEIVED', '0000-00-00', 'NA', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (29, '431839', '2018-08-01', 'SW DD', 'ANALOGNC CEMERA - NIKON FM 3A (FL-50 MMF)', 'AO KPD', 'NA', 'NA', '0000-00-00', 'RECEIVED', '0000-00-00', 'NA', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (30, '431826', '2018-08-01', 'SW DD', 'ANALOGNC CAMERA - PENTAN- K1000(FL-50 MMF)', 'AO KPD', 'NA', 'NA', '0000-00-00', 'RECEIVED', '0000-00-00', 'NA', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (31, '431832', '2019-01-09', 'SW DD', 'REQUIREMENT OF ONE PORTABLE MINI PROJECTOR (SONY MPCD-1 COMPACT0 available at gem govt market place for the use of mobile forensic unit', 'DC DD II', 'AC DD I', 'HA DD', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (32, '431889', '2018-05-26', 'SW DD', '12 nos. of chairs', 'Jt.CP(O)', 'DC DD (II), AC DD (I)', 'Building Section', '0000-00-00', 'REJECTED', '0000-00-00', '6 RECEIVED AND REMAINING REJECTED', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (33, '431887', '2018-06-20', 'SW DD (Videography)', 'SD cards', 'Jt.CP(O)', 'DC DD (II), AC DD (I)', 'NA', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (34, '431899', '2018-06-20', 'SW DD(Videography)', 'Epson Ultra Chrome D6 INK for Epson Sure Lab-D3000', 'Jt.CP (O)', 'DC DD (II), AC DD (I)', 'NA', '0000-00-00', 'RECEIVED', '2019-12-27', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (35, '441862', '2018-06-20', 'SW DD(Videography)', 'Talk Back System and some peripherals', 'Jt.CP (O)', 'DC DD (II), AC DD (I)', 'NA ', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (36, '441817', '2018-05-28', 'SW DD', 'Requirement of 12 nos. of chairs out of which 06 received.', 'Jt.CP (O)', 'DC DD (II), AC DD (I)', 'Building section', '0000-00-00', 'RECEIVED', '0000-00-00', 'Supply date is not mentioned.', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (37, '441838', '2018-05-22', 'SW DD', 'AMC for four Interrogation rooms', 'Jt.CP (O)', 'DC DD (II), AC DD (I)', 'NA', '0000-00-00', 'REJECTED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (38, '441881', '2018-03-31', 'SW DD', 'Prayer for 03 nos.Laptops ', 'DC DD (II)', 'AC DD (I)', 'NA', '0000-00-00', 'RECEIVED', '2018-05-24', '4 RECEIVED', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (39, '441824', '2018-04-11', ' SW DD', 'Requirement of Rasper Acrylic Sandwich', 'Jt.CP (O)', 'DC DD (II), AC DD (I)', 'HA DD', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (40, '441865', '2018-04-02', 'SW DD', '10 nos. of Electrical connection at Varandah of FP Section', 'DC DD (II)', 'AC DD (I)', 'Building Section', '0000-00-00', 'REJECTED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (41, '441826', '2018-04-02', 'SW DD', '04 nos. of Group-D (Dome)', 'Jt.CP (Establishment)', 'DC DD (II)', 'NA ', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (42, '441868', '2018-09-06', 'SW DD', 'Specific SD Cards', 'Jt.CP (O)', 'DC DD (II), AC DD (I)', 'HA, DD', '0000-00-00', 'RECEIVED', '0000-00-00', 'Only Sony SF UX2 SDXC Card Class X received(128 gb 5 piece)', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (43, '441826', '2018-06-26', 'SW DD', 'Repair of printer', 'DC DD (II)', 'AC DD (I)', 'HA, DD', '0000-00-00', 'RECEIVED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (44, '441839', '2018-06-15', 'SW DD', 'Replacement of Cartridges for printers', 'DC DD (II)', 'AC DD (I)', 'HA, DD', '0000-00-00', 'RECEIVED', '0000-00-00', '3 piece received', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (45, '441847', '2018-09-11', 'SW DD', 'Prayer for one Motor Cycle', 'Special CP (II)', 'Jt.CP (Crime), DC DD (II)', 'MTO, DD', '0000-00-00', 'RECEIVED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (46, '441825', '2018-05-31', 'SW DD', 'Requirement of 3 nos. of i7 Laptops', 'DC DD (II)', 'AC (Admin)', 'NA', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (47, '441843', '2018-11-26', 'SW DD', 'Posting of Constables (3 nos.)', 'Jt.CP (Crime)', 'DC DD (II)', 'NA', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (48, '441860', '2018-08-21', 'SW DD', 'Requisition for Specific Computer Peripherals', 'DC DD (II)', 'AC DD (I)', 'HA, DD', '0000-00-00', 'FULLY NOT RECEIVED', '2018-10-10', '32 GB PENDRIVE,64 GB PEN DRIVE,8 GB MICRO SD CARD,DDR 3 RAM(4 GB) RECEIVED', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (49, '441855', '2018-04-16', 'SW DD', 'Finger Print development articles', 'DC DD(II)', 'AC DD (I)', 'HA DD', '0000-00-00', 'RECEIVED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (50, '441850', '2018-07-03', 'SW DD', 'REPLACEMENT OF CARTRIDGES AND SUPPLY OF TONER', 'DC DD (II)', 'AC DD (I)', 'HA DD', '0000-00-00', 'RECEIVED', '0000-00-00', 'ONLY HP-M226dn LASER PRINTER RECEIVED 2 pieice ', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (51, '441896', '2018-10-01', 'SW DD', 'SPECIFIC LISTED ARTICLES IN THE ANNUAL TENDER LIST', 'Jt. CP (O)', 'DC DD (II)', 'HA TENDER ', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (52, '441823', '2018-10-03', 'SW DD', 'VARIOUS STATIONARY ARTICLES ', 'DC DD (II)', 'AC DD (I)', 'HA DD ', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (53, '441845', '2018-04-17', 'SW DD', 'AUDIO RECORDER PRODUCTS WITH OR WITHOUT VIDEO', 'Jt.CP (CRIME)', 'DC DD(II)', 'N/A', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (54, '441816', '2018-04-23', 'SW DD', 'SD CARD & HEAD SET', 'AO KPD', 'OC SW DD', 'N/A', '0000-00-00', 'RECEIVED', '0000-00-00', 'ONLY 5 PCS OF SONY SF128UX2 120GB SDXC CARDS RECEIVED', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (55, '451868', '2018-04-09', 'SW DD', '2 NO.S OF LATEST VERSION OF MS OFFICE', 'DC DD (II)', 'AC DD (I)', 'COMPUTER CELL KPD', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (56, '451851', '2018-07-24', 'SW DD', 'BNC PLUG COAXIAL CABLE ', 'Jt.CP (O)', 'DC DD (II)', 'N/A', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (57, '451860', '2018-04-14', 'SW DD ', 'POSTING OF 2 CONSTABLES FOR PLAN SECTION', 'DC DD (II)', 'AC DD (I)', 'N/A', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (58, '451823', '2019-01-25', 'SW DD ', 'REQUIREMENT OF ONE PLOTTER', 'Jt.CP (O)', 'DC DD (II), AC DD(I)', 'N/A', '0000-00-00', 'RECEIVED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (59, '451870', '2019-02-25', 'SW DD', 'REPLACEMENT OF ONE COMPUTER OF PORTRAIT PARLEY', 'Jt.CP (O)', 'DC DD (II), AC DD (A)', 'COMPUTER CELL KPD', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (60, '451838', '2019-03-11', 'SW DD', 'Requirement of three (3) nos. of Fingerprint Inkless Pads for Fingerprint Section, Scientific Wing, DD', 'DC DD(II)', 'AC DD(I), DC DD(II)', 'HA DD', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (61, '451898', '2019-02-28', 'SW DD', 'Requirement of one specified article for the use of scientific wing, DD', 'Jt. CP (O)', 'AC DD(I), DC DD(II), JT. CP(O)', 'EQUIPMENT CELL', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (62, '451832', '2019-02-28', 'SW DD', 'Requirement of some articles for the use of Scientific Wing, DD', 'Jt. CP (O)', 'OC SW, AC DD(I), DC DD(II), JT. CP (O)', 'Equipment Cell', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (64, '451875', '2019-03-11', 'SW DD', 'Requirement of 01 no. of HDMI to AV Converter for the use of Videography Section of Scientific Wing, DD', 'DC DD(II)', 'OC SW, AC DD(I), DC DD(II)', 'HA DD', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (66, '451816', '2019-04-11', 'SW DD', 'PRAYER FOR 20 PIECES OF JIO DONGLE WITHOUT SIM', 'Jt.CP (O)', 'DC DD (II)', 'OC TELEPHONE', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (67, '451820', '2019-05-03', 'SW DD', 'PRAYER TO PROVIDE 30 PCS OF FX-LI-ION AN -2000D BATTERY A', 'Jt.CP (O)', 'DCDD (II)', 'HA EQP', '0000-00-00', 'RECEIVED', '2019-12-03', '15 PENDING', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (68, '451854', '2018-12-04', 'SW DD', 'PRAYER FOR LICENSE RENEW OF FORTIGATE 50E FIREWALL DEVICE ', 'DC DD (II),AC DD (I)', 'DC DD (II)', 'HA EQP', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (69, '451814', '2019-02-28', 'SW DD', 'REQUIREMENT OF ONE BLACK MAGIC SDI TO HDMI CONVERTER', 'Jt.CP (O),DC DD (II),AC DD(I)', 'DC DD (II)', 'HA EQP', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (70, '451861', '2019-02-28', 'SW DD', 'REQUIREMENT OF ONE BLACK MAGIC OPTICAL TO SDI CONVERTER', 'Jt.CP (O),DC DD (II),AC DD(I)', 'DC DD (II)', 'HA EQP', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (71, '451894', '2019-04-23', 'SW DD', 'PRAYER FOR PASSING NECESSARY ORDER TO SUPPLY-1 CONECTOR 50 PCS,BOOT (CANARE/BELDEN) OF 50 PCS', 'Jt.CP (O),DC DD (II)', 'DC DD (II)', 'HA EQP', '0000-00-00', 'RECEIVED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (72, '451851', '2018-09-11', 'SW DD', 'PRAYER FOR A.M.C OF 6 KVA UPS', 'Jt.CP (O),DC DD (II),AC DD(I)', 'DC DD (II)', 'HA EQP', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (73, '451842', '2018-04-11', 'SW DD', 'PRAYER FOR AMC OF STILL CAMERAS ', 'Jt.CP (O),DC DD (II),AC DD(I)', 'DC DD (II)', 'HA EQP', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (74, '451823', '2018-09-11', 'SW DD', 'PRAYER FOR A.M.C OF STILL AND VIDEO CAMERA ', 'Jt.CP (O),DC DD (II),AC DD(I)', 'DC DD (II)', 'HA EQP', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (75, '451891', '2018-09-11', 'SW DD', 'PRAYER FOR A.M.C FOR BACK PACK SYSTEM,CAMERA', 'Jt.CP (O),DC DD (II),AC DD(I)', 'DC DD (II)', 'HA EQP', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (76, '451831', '2019-04-22', 'SW DD', 'PRAYER FOR PASSING NECESSARY ORDER FOR SUPPLYING 40 PCS OF SDI CABLE WIRE ', 'Jt.CP (O),DC DD (II),AC DD(I)', 'DC DD (II)', 'HA EQP', '0000-00-00', 'RECEIVED', '0201-08-26', '20 PICES RECEIVED', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (77, '451888', '2019-04-29', 'SW DD', 'PRAYER FOR PROCUREMENT OF 5 NO.S  OF SONY AX40 4K HANDICAM', 'DC DD (II),AC DD(I)', 'DC DD (II)', 'HA EQP', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (78, '451869', '2019-04-17', 'SW DD', 'PRAYER FOR PROVIDING WIRELESS WIFI ADAPTER AND WIFI RANGE EXTENDER', 'DC DD (II),AC DD(I)', 'DC DD (II)', 'HA DD', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (79, '451810', '2019-04-29', 'SW DD', 'PRAYER FOR REPAIR OF 2 LAPTOPS VIDE MODEL NO. 1.(TOSHIBA-PSAA9L-17E04H) & 2.HP-COMPAQ-nx6320 ', 'Jt.CP(O)', 'DC DD (II)', 'HA EQP', '0000-00-00', 'RECEIVED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (80, '451848', '2019-06-03', 'SW DD', 'REQUIREMENT OF 175 NO.S OF 8GB MICRO SD CARD(PREFERABLY KINGSTONE) FOR PHOTOGRAPHY SECTION )', 'DCDD (II),AC DD (I)', 'DC DD (II)', 'HA DD', '0000-00-00', 'RECEIVED', '2019-07-18', '150 PICE RECEIVED', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (81, '461836', '2019-06-07', 'SW DD', 'REQUIREMENT OF REFILLING OF PRINTING INK OF P-1108 HP PRINTER(CARTRIDGE -88A))', 'DCDD (II),AC DD (I)', 'Jt.CP(O),DCDD (II),AC DD (I)', 'HA DD', '0000-00-00', 'RECEIVED', '2019-06-20', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (82, '461849', '2019-03-30', 'SW DD', 'REQUIREMENT OF REFILLING OF PRINTING INK OF EPSON AND CANON PRINTER ', 'DCDD (II),AC DD (I)', 'DC DD (II),', 'HA DD', '0000-00-00', 'RECEIVED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (83, '461872', '2019-04-17', 'SW DD', 'PRAYER FOR PROCUREMENT OF 07 NO.S OF 27\"  MONITOR ', 'Jt.CP(O),DC DD (II),AC DD (I)', 'DC DD (II),', 'HA EQP', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (84, '461821', '2019-04-02', 'SW DD', 'PRAYER FOR PROVIDING 1 HP COLOUR LESER JET PRINTER', 'Jt.CP(O),DCDD (II),AC DD (ADMIN)', 'DC DD (II)', 'HA EQP,OC COMPUTER CELL', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (85, '461887', '2019-03-30', 'SW DD', 'PRAYER FOR REPAIR/SERVICING OF 2 HP SCANJET(LASER SCANNER) MODEL NO.-8350', 'DC DD (II),AC DD (I)', 'DC DD (II)', 'HA DD', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (86, '461839', '2019-03-30', 'SW DD', 'REQUIREMENT OF 2 NO.S OF WIRELESS MOUSE FOR EFFECTIVE USE FOR NEWLY PROCURED 3D LESER SCANNER IN GEM', 'DCDD (II),AC DD (I)', 'DC DD (II)', 'HA DD', '0000-00-00', 'RECEIVED', '0000-00-00', '6 MOUSE & KEYBOARD COMBO PACK', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (87, '461895', '2019-04-18', 'SW DD', 'PRAYER FOR REPAIR OF 3 HP LESER JET PRINTER', 'DCDD (II),AC DD (I)', 'DC DD (II)', 'HA DD', '0000-00-00', 'RECEIVED', '0000-00-00', 'MODEL NO.P1108- 1PICE, MODEL NO.- 1008- 2 PICES', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (88, '461893', '2019-02-25', 'SW DD', 'REQUISITION FOR REPAIR / REPLACE ONE COMPUTER FOR THE USE OF PORTRAIT PERLEY SECTION', 'Jt.CP(O),DC DD (II),AC DD (A)', 'DC DD (II)', 'COMPUTER CELL', '0000-00-00', 'PENDING', '0000-00-00', 'MODEL NO.- HP-SL.NO.-3CQ2410XL7,CPU NO.-HP-INA245RDVS ', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (89, '461836', '2019-04-24', 'SW DD', 'PRAYER FOR REPAIR OF 1 XEROX MACHINE VIDE MODEL NO.-KYOCERA-KILBURN-KM-1635', 'Jt.CP(O),DCDD (II),AC DD (I)', 'DC DD (II)', 'HA EQP', '0000-00-00', 'RECEIVED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (90, '461871', '2019-04-23', 'SW DD', 'PRAYER FOR PASSING NECESSARY ORDER TO SUPPLY 300 PC.S COLOR FILMS(200 ASA KODAK/FUZI 200) FOR PHOTOGRAPHY SECTION', 'DCDD (II),AC DD (I)', 'DC DD (II)', 'HA DD', '0000-00-00', 'RECEIVED', '0000-00-00', '150 PICE DUE', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (91, '461830', '2019-03-11', 'SW DD', 'REQUIREMENT OF 3 NO.S OF FINGERPRINT LINKLESS PAD FOR FINGER PRINT SECTION', 'DCDD (II),AC DD (I)', 'DC DD (II)', 'HA DD', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (92, '461893', '2018-10-01', 'SW DD', 'PRAYER FOR INCLUSION OF THE SPECIFIC LISTED ARTICLES OC SW DD IN THE ANNUAL TENDER LIST', 'Jt.CP(O),DCDD (II),AC DD (I)', 'DC DD (II)', 'HA TENDER ', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (93, '461881', '2019-01-14', 'SW DD', 'PRAYER FOR 2 NO.S OF SAFARI SUIT FOR EACH OF OCS,OFFICERS AND OTHER POLICE PERSONNEL', 'Jt.CP(O),DCDD (II),AC DD (I)', 'DC DD (II)', 'HA DD', '0000-00-00', 'RECEIVED', '2019-10-19', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (94, '461840', '2019-04-17', 'SW DD', 'FURNISHING THE DETAILS OF COMPUTER RELATED ARTICLES FOR THE USE OF SW DD ALONG WITH SPECIFICATION ON AVAILABILITY IN GEM PORTAL ', 'DCDD (II),AC DD (A)', 'DC DD (II)', 'HA DD', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (95, '461855', '2019-03-26', 'SW DD', 'PRAYER FOR CONSIDERATION OF MARKET SURVEY BY EB , KOLKATA POLICE i/c/w TENDER VIDE MEMO NO. 05536/TENDER+ENCLO, Dt.-25/03/2019', 'Jt.CP(CRIME),DCDD (II),AC DD (I)', 'DC DD (II)', 'HA DD', '0000-00-00', 'REJECTED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (96, '461873', '2019-05-20', 'SW DD', 'REQUIREMENT OF CEILING FAN,PEDESTAL FAN,TUBE LIGHTS FOR USE OF SWDD PRESENTLY HOUSED AT KIT BUILDING', 'AC DD (A)', 'AC DD (A)', 'HA DD', '0000-00-00', 'REJECTED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (97, '461817', '2019-07-10', 'SW  DD', 'PRAYER FOR PROCUREMENT OF HIGH CONFIGURATION COMPUTER (02) HAVING HIGH-END SOFTWARE COMPATIBILITY, URGENTLY REQUIRED FOR THE USE OF SCIENTIFIC WING, DD.', 'AC, DD (I)', 'JT. CP (O)', 'OC, COMPUTER CELL', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (98, '461867', '2019-07-18', 'SW DD', 'REQUIREMENT OF SOME SPECIFIC COMPUTER PERIPHERALS', 'AC, DD (I)', 'JT. CP (O)', 'COMPUTER CELL', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (99, '461832', '2019-07-18', 'SW DD', 'REQUIREMENT OF FOUR(4) NOS. OF MEDIUM SIZE TRIPOD', 'AC, DD(I)', 'JT. CP(O)', 'HA EQP.', '0000-00-00', 'RECEIVED', '2019-08-26', '2 PICES RECEIVED', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (100, '461842', '2019-07-04', 'SW DD', 'REQUIREMENT OF 20 WEBCAM AS PART OF IFVP PROJECT', 'AC DD(I), Jt CP (O)', 'DC DD (II)', 'HA EQP', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (101, '461845', '2019-07-04', 'SW DD', 'REQUIREMENT OF 20 NOS. OF HIGH DEFINITION HEADSET WITH VOICE RECORD AND TELEPHONY', 'AC, DD(I). JT. CP (O)', 'DC, DD(II)', 'HA (EQP)', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (102, '461848', '2019-07-16', 'SW DD', 'PRAYER FOR SUPPLY OF 61 NOS. OF RAIN COATS (SHIRT & TROUSER) FOR THE USE OF POLICE PERSONNEL OF SCIENTIFIC WING', 'AC DD(I), JT. CP(O)', 'DC DD(II)', 'ICD', '0000-00-00', 'RECEIVED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (104, '461848', '2018-06-20', 'SW DD', 'REQUISITION FOR BLACK MAGIC WEB PRESENTER', 'Jt. CP(O)', 'DC DD (II),AC DD(I)', 'HA EQP', '0000-00-00', 'RECEIVED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (105, '461854', '2019-10-26', 'SW DD', 'PRAYER FOR PROVIDING NECESSARY ASSISTANCE TO INSTALL HARDWARE ITEMS OF FRS AT DATA CENTRE LALBAZAR', 'SUB-ASST.ENGINNER(ELECTRICAL)', 'PWD', 'N/A', '0000-00-00', 'RECEIVED', '0000-00-00', 'RECEIVED BY PWD', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (106, '461849', '2019-07-19', 'SW DD', 'PROPOSAL FOR FORMATION OF COLOUR FLIM PROCESS DEVELOPER AT PHOTOGRAPHY SECTION SW DD,FOR CRIME SCENE RELATED IMAGE DEVELOPMENT', 'AC DD (I),DC DD(II)', 'JT. CP (Crime)', 'HA (EQP)', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (108, '461815', '2019-11-01', 'SW DD', 'REQUIREMENT OF REFILLING OF PRINTING INK OF EPSON AND CANON PRINTER FOR THE USE OF SW DD', 'AC DD (I)', 'DCDD (II)', 'HA DD', '0000-00-00', 'RECEIVED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (109, '461855', '2019-10-19', 'SW DD', 'UPGRADATION OF MSI GL 63 8RE LAPTOP USED FOR 3 SCANNER', 'AC, DD(I). JT. CP (Crime)', 'JT. CP(O)', 'HA (EQP)', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (112, '461828', '2019-07-27', 'SW DD', 'PRAYER FOR ARRANGING AN AUDIT FOR REQUIREMENT OF SUITABLE AIR CONDITIONING SYSTEM AT SW DD WHICH IS UNDER THE PROCESS OF RE CONSTRUCTION ON THE 3RD FLOOR OF DD BUILDING LALBAZAR', 'AC DD(I) ', ' Jt. CP (Crime)', 'HA BUILDING', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (113, '461848', '2019-11-16', 'SW DD', 'REQUIREMENT OF TWO HP i5 ADAPTER ', 'AC DD(I)', 'DC DD (II)', 'HA DD', '0000-00-00', 'RECEIVED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (114, '461842', '2019-07-27', 'SW DD', 'PRAYER FOR MAKING AMC OF 2 PLOTTERS OF PLAN MAKING SECTION SW DD', 'AC DD(I)', 'Jt.CP(Crime)', 'COMPUTER CELL ', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (115, '461851', '2019-07-27', 'SW DD', 'PRAYER FOR REPAIRING OF 2 PLOTTERS OF PLAN MAKING SECTION SW DD', 'AC DD (I)', 'Jt.CP(CRIME)', 'COMPUTER CELL ', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (116, '461816', '2019-07-29', 'SW DD', 'PRAYER FOR SUPPLY OF COTTON MADE HALF JACKET,HAND GLAPS,SHOE CAPS,EXHIBIT COLLECTING BAG FOR THE USE OF OFFICERS OF AND MEN OF SW DD AT THE TIME OF PO VISIT', 'AC DD(I)', 'Jt.CP (Crime)', 'ICD', '0000-00-00', 'PENDING', '0000-00-00', 'only 10 hand glaps received', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (117, '471818', '2019-08-07', 'SW DD', 'REQUIREMENT OF THREE HP 51A CARTRIDGE ', 'AC DD(I)', 'Jt.CP (Crime)', 'HA DD', '0000-00-00', 'RECEIVED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (118, '471871', '2019-08-01', 'SW DD', 'PRAYER FOR SEEKING NECESSARY  PERMISSION TO REPAIR 8 NO.S OF OLD CAMERAS(5 DIGITAL AND 3 ANALOG) OF PHOTOGRAPHY SECTION', 'AC DD (I)', 'Jt.CP (Crime)', 'HA EQP', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (121, '471878', '2019-11-26', 'SW DD', 'REQUIREMENT OF SOME ESSENTIAL ARTICLES REQUIRED FOR  MAKING IDENTITY CARD OF DETECTIVE DEPARTMENT', 'AC DD(I)', 'Jt.CP (Crime)', 'HA DD', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (122, '471826', '2019-11-26', 'SW DD', 'PRAYER FOR SOME ESSENTIAL TENDERIZED VIDEO TRANSMITTING EQUIPMENTS', 'AC DD (I)', 'Jt.Crime ', 'HA EQP', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (123, '471868', '2020-01-03', 'SW DD', 'REQUIREMENT OF 7 NO.S OF NEW 88A CARTRIDGES FOR THE USE OF SW DD ', 'AC DD (I)', 'Jt. CP (Crime)', 'HA DD', '0000-00-00', 'RECEIVED', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (124, '471889', '2020-01-16', 'SW DD', 'REQUESTING FOR CARTRIDGE FOR HP DESIGN JET T2530 PLOTTER FOR PLAN SECTION DD ', 'Jt.CP(Crime)', 'AC DD (I)', 'HA DD', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (125, '471843', '2020-01-17', 'SW DD', 'REQUIREMENT OF  THE FOLLOWING NEW TONNER FOR HP COLOUR LASERJET 2605 dn PRINTER', 'Jt. CP (CRIME)', 'AC DD I', 'HA DD', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (126, '471824', '2019-01-09', 'SW DD', 'REQUIREMENT OF TOTAL THREE NO.S OF MULTI-PURPOSE COPIER AND PRINTING MECHINE', 'DC DD(II),AC DD (II)', 'DC DD(II)', 'HA DD', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (128, '471882', '2019-10-26', 'SW DD', 'REQUISITION FOR PROCUREMENT OF ONE ORPHICARD HALF PANEL RIBBON', 'DC DD(II),AC DD(I)', 'AC DD(I)', 'HA DD', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (149, '471835', '2019-10-28', 'SW DD', 'MICRO SD CARD 8GB', 'DC DD (II)', 'AC DD (I)', 'HA DD', '0000-00-00', 'RECEIVED', '2020-02-18', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (150, '471878', '2018-01-30', 'SW DD', 'REQUIREMENT OF SOME ACCESSORIES FOR GETTING FEED OF LIVE CAMERAS AT THE ROOMS OF Ld.CP AND Jt,CP(HQ)', 'Jt.CP(Crime),AC DD(I)', 'Jt.CP(O)', 'HA EQP', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (152, '471816', '1970-01-01', 'SW DD', 'PRAYER FOR SUPPLY OF SAME ARTICLES REQUIRED FOR THE CONNECTIVITY OF NETWORK IN ROOM OF AC DD( I) ', 'DC DD(I)', 'AC DD (I)', 'HA DD', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (153, '471881', '2020-02-20', 'SW DD', 'PRAYER FOR 15 PCS BLACKMAGIC DESIGN DECKLINK SDI 4K CAPTURE & PAYBACK CARD SOME SDI CABLES TO SUPPLY UNINTERRUPTED VIDEO FROM BACK PACK ROOM TO NEW CONTROL ROOM', 'AC DD(I)', 'Jt.CP(O)', 'ACCR', '1970-01-01', 'PENDING', '1970-01-01', '', '2020-07-04 15:05:00', 1, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (154, '471875', '2020-02-28', 'SW DD', 'REQUISITION FOR SOME SPECIFIC COMPUTER PERIPHERALS URGENTLY REQUIRED DIFFERENT SECTIONS UNDER SCIENTIFIC WING,DD TO PERFORM THEIR COMPUTER RELATED JOBS MORE EFFECTIVELY ', 'AC DD(I)', 'Jt.CP(CRIME)', 'HA DD', '1970-01-01', 'PENDING', '1970-01-01', '', '2020-07-05 09:41:00', 1, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (155, '471890', '1970-01-01', 'SW DD', 'REQUISITION FOR SOME SPECIFIC COMPUTER PERIPHERALS URGENTLY REQUIRED DIFFERENT SECTIONS UNDER SCIENTIFIC WING,DD TO PERFORM THEIR COMPUTER RELATED JOBS MORE EFFECTIVELY ', 'AC DD(I)', 'Jt.CP(CRIME)', 'HA DD', '0000-00-00', 'PENDING', '0000-00-00', '', '0000-00-00 00:00:00', 0, 1);
INSERT INTO `requisition` (`r_id`, `r_orn`, `r_date`, `r_sectionfor`, `r_sub`, `r_towhom`, `r_forwardedto`, `r_dealingsec`, `r_recievedate`, `r_status`, `r_supplydate`, `r_remarks`, `r_datetime`, `r_flag`, `r_userid`) VALUES (157, '000222', '2020-07-09', 'swdd', 'swdd', 'swdd', 'demo', 'hamod', '2020-07-09', 'PENDING', '2020-07-09', 'swdd', '2020-07-09 15:02:00', 1, 1);


#
# TABLE STRUCTURE FOR: requisition_file
#

DROP TABLE IF EXISTS `requisition_file`;

CREATE TABLE `requisition_file` (
  `rf_id` int(11) NOT NULL AUTO_INCREMENT,
  `rf_rid` int(11) DEFAULT NULL,
  `rf_filename` varchar(100) DEFAULT NULL,
  `rf_datetime` datetime DEFAULT NULL,
  `rf_flag` int(11) DEFAULT NULL,
  `rf_userid` int(11) DEFAULT NULL,
  PRIMARY KEY (`rf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: requisition_items
#

DROP TABLE IF EXISTS `requisition_items`;

CREATE TABLE `requisition_items` (
  `ri_id` int(11) NOT NULL AUTO_INCREMENT,
  `ri_rid` int(11) NOT NULL,
  `ri_itemid` int(11) NOT NULL,
  `ri_qty` varchar(255) NOT NULL,
  `ri_datetime` datetime NOT NULL,
  `ri_flag` int(11) NOT NULL,
  `ri_userid` int(11) NOT NULL,
  PRIMARY KEY (`ri_id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=latin1;

INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (3, 104, 18, '4', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (4, 104, 17, '5', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (5, 106, 41, '1', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (6, 107, 5, '150', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (7, 110, 42, '1200 mtr.', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (8, 110, 46, '6 PICE', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (9, 110, 45, '5 PICE', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (10, 110, 44, '5 PICE', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (11, 110, 43, '5 PICE', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (12, 113, 47, '2', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (15, 115, 49, '2', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (16, 118, 48, '3', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (17, 118, 1, '5', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (18, 117, 29, '2', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (19, 116, 50, '60', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (20, 116, 52, '60', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (21, 116, 51, '60', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (22, 116, 53, '60', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (23, 120, 1, '3', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (24, 120, 48, '5', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (25, 121, 54, '6', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (26, 121, 56, '5', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (27, 121, 55, '400', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (28, 122, 42, '1200 MTR.', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (29, 122, 46, '6', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (30, 122, 45, '5', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (31, 122, 44, '5', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (32, 122, 43, '5', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (33, 119, 29, '3', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (34, 123, 29, '7', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (35, 124, 29, 'PHOTO BLACK-1,CYAN -1,MAGENTA -1,YELLOW -1,MATTE BLACK-1,GREY-1', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (36, 125, 57, '1', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (37, 125, 60, '1', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (38, 125, 59, '1', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (39, 125, 58, '1', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (40, 126, 61, '1', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (41, 126, 62, '2', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (42, 127, 61, '1', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (43, 127, 62, '2', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (44, 128, 63, '1', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (68, 149, 5, '150', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (69, 150, 65, '2', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (70, 150, 66, '2', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (71, 150, 67, '5', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (72, 150, 68, '2', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (73, 150, 69, '2', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (74, 150, 70, '2', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (75, 151, 5, '10', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (76, 151, 12, '10', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (77, 152, 71, '1', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (78, 152, 72, '1', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (79, 152, 73, '1', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (86, 155, 12, '10', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (87, 155, 5, '10', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (90, 158, 19, '4', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (91, 159, 19, '4', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (92, 160, 19, '4', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (93, 161, 20, '4', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (94, 162, 20, '5', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (95, 163, 20, '5', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (96, 164, 21, '5', '0000-00-00 00:00:00', 0, 0);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (99, 153, 74, '15', '2020-07-04 15:05:00', 1, 1);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (100, 153, 75, '08', '2020-07-04 15:05:00', 1, 1);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (101, 153, 76, '08', '2020-07-04 15:05:00', 1, 1);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (102, 153, 77, '16', '2020-07-04 15:05:00', 1, 1);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (105, 154, 12, '10', '2020-07-05 09:41:00', 1, 1);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (106, 154, 5, '10', '2020-07-05 09:41:00', 1, 1);
INSERT INTO `requisition_items` (`ri_id`, `ri_rid`, `ri_itemid`, `ri_qty`, `ri_datetime`, `ri_flag`, `ri_userid`) VALUES (108, 157, 3, '1', '2020-07-09 15:02:00', 1, 1);


#
# TABLE STRUCTURE FOR: user_group
#

DROP TABLE IF EXISTS `user_group`;

CREATE TABLE `user_group` (
  `ug_id` int(11) NOT NULL AUTO_INCREMENT,
  `ug_name` varchar(255) DEFAULT NULL,
  `ug_permission` text,
  `ug_datetime` datetime DEFAULT NULL,
  `ug_flag` int(11) DEFAULT NULL,
  `ug_userid` int(11) DEFAULT NULL,
  PRIMARY KEY (`ug_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `user_group` (`ug_id`, `ug_name`, `ug_permission`, `ug_datetime`, `ug_flag`, `ug_userid`) VALUES (1, 'Admin', 'a:6:{i:0;s:13:\"createprocess\";i:1;s:13:\"updateprocess\";i:2;s:10:\"uploadscan\";i:3;s:11:\"createusers\";i:4;s:11:\"updateusers\";i:5;s:15:\"createusergroup\";}', '2020-06-24 10:03:00', 1, 1);
INSERT INTO `user_group` (`ug_id`, `ug_name`, `ug_permission`, `ug_datetime`, `ug_flag`, `ug_userid`) VALUES (2, 'Staff', 'a:3:{i:0;s:13:\"createprocess\";i:1;s:13:\"updateprocess\";i:2;s:10:\"uploadscan\";}', '2020-06-24 20:02:00', 1, 1);


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `u_id` int(11) NOT NULL AUTO_INCREMENT,
  `u_ugid` int(11) DEFAULT NULL,
  `u_title` varchar(255) NOT NULL,
  `u_username` varchar(255) NOT NULL,
  `u_password` varchar(255) NOT NULL,
  `u_datetime` datetime NOT NULL,
  `u_flag` int(11) NOT NULL,
  `u_userid` int(11) NOT NULL,
  `u_ip` varchar(255) NOT NULL,
  PRIMARY KEY (`u_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `users` (`u_id`, `u_ugid`, `u_title`, `u_username`, `u_password`, `u_datetime`, `u_flag`, `u_userid`, `u_ip`) VALUES (1, 1, 'Anirban Seth', 'anirban', 'o9VumscQ8oDjOtW+fO4itsgow9mvctJ5x85/3WrQw5ILrZRHmGFSWrP4gj+lxuP4Q8iftiatSDpJkjBtv7MVCw==', '2020-06-24 20:36:00', 1, 1, '::1');
INSERT INTO `users` (`u_id`, `u_ugid`, `u_title`, `u_username`, `u_password`, `u_datetime`, `u_flag`, `u_userid`, `u_ip`) VALUES (2, 2, 'Aminur Rahaman', 'user1@pms.com', 'lk9qfUsqkoQlGxcXzF4kPJOMwwKDzy5bUsq1LXqycqdhmOwfY2Jk89kh/ymijNnfaV6kBCm/yRb+yYfJWn31fw==', '2020-06-24 19:56:00', 1, 2, '::1');
INSERT INTO `users` (`u_id`, `u_ugid`, `u_title`, `u_username`, `u_password`, `u_datetime`, `u_flag`, `u_userid`, `u_ip`) VALUES (3, 2, 'Manoj Roy', 'user2@pms.com', 'xElJkmRoBu3v70UKyd3xrAiJ0aN03+Kgg0IyS26jnZL5NL8goT2NgTGeNZot2Ji5+tyDKn2RBGUSH65BeTqAfg==', '2020-06-26 09:17:00', 1, 1, '::1');


